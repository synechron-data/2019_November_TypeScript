// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// class Person implements IPerson {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 37);
// console.log(p1.greet("Hi"));

// let p2: IPerson = new Person("Manish", 37);
// console.log(p2.greet("Hey"));

// ------------------------------------ Multiple Interface Implementation

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (msg: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// class Person implements IPerson, IWork {
//     name: string;
//     age: number;

//     constructor(n: string, a: number) {
//         this.name = n;
//         this.age = a;
//     }

//     greet(msg: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am working";
//     }
// }

// let p1: Person = new Person("Abhijeet", 37);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// ----------------------------------- Interface can extend other Interfaces

interface IPerson {
    name: string;
    age: number;
    greet: (msg: string) => string;
}

interface IWork {
    doWork(): string;
}

interface ICustomer extends IPerson {
    doShopping(): void;
}

class Person implements IPerson, ICustomer, IWork {

    name: string;
    age: number;

    constructor(n: string, a: number) {
        this.name = n;
        this.age = a;
    }

    greet(msg: string): string {
        return "Hello";
    }

    doWork(): string {
        return "I am working";
    }

    doShopping(): void {
        console.log("Let's go to Mall");
    }
}

// let p1: Person = new Person("Abhijeet", 37);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());
// p1.doShopping();

// Interface Extraction
// let p1: IPerson = new Person("Abhijeet", 37);

// let p2: ICustomer = new Person("Abhijeet", 37);

// let p3: IWork = new Person("Abhijeet", 37);

// ------------------------------------------------- Interface can extend from class

// class Vehicle {
//     constructor(public make: string) { }

//     getMake() {
//         return this.make;
//     }
// }

// class Engine {
//     constructor(public manufacturer: string) { }

//     getManufacturer() {
//         return this.manufacturer;
//     }
// }

// interface IVehicle extends Vehicle, Engine { }

// class FourWheeler implements IVehicle {
//     public make: string;
//     public manufacturer: string;

//     getMake(): string {
//         throw new Error("Method not implemented.");
//     }

//     getManufacturer(): string {
//         throw new Error("Method not implemented.");
//     }
// }