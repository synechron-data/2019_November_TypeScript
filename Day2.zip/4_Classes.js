var BankAccount = (function () {
    function BankAccount(_accnumber, _accname) {
        this._accnumber = _accnumber;
        this._accname = _accname;
    }
    Object.defineProperty(BankAccount, "BankName", {
        set: function (value) {
            BankAccount._bankname = value;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BankAccount.prototype, "BankName", {
        get: function () {
            return BankAccount._bankname;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BankAccount.prototype, "AccountName", {
        get: function () {
            return this._accname;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(BankAccount.prototype, "AccountNumber", {
        get: function () {
            return this._accnumber;
        },
        enumerable: true,
        configurable: true
    });
    BankAccount._bankname = "HDFC";
    return BankAccount;
}());
BankAccount.BankName = "ICICI";
var a1 = new BankAccount(1, "Manish");
console.log("Bank Name: ", a1.BankName);
console.log("Account Number: ", a1.AccountNumber);
console.log("Account Holder Name: ", a1.AccountName);
var a2 = new BankAccount(2, "Abhijeet");
console.log("Bank Name: ", a2.BankName);
console.log("Account Number: ", a2.AccountNumber);
console.log("Account Holder Name: ", a2.AccountName);
//# sourceMappingURL=4_Classes.js.map