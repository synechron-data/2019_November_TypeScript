var Manager = (function () {
    function Manager() {
        this.name = "Manager";
    }
    return Manager;
}());
var Developer = (function () {
    function Developer() {
        this.name = "Developer";
    }
    return Developer;
}());
var factory = (function () {
    return {
        getEmployee: function (arg) {
            return new arg();
        }
    };
})();
console.log(factory.getEmployee(Manager));
console.log(factory.getEmployee(Developer));
//# sourceMappingURL=7_Assignment.js.map