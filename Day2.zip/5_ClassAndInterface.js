var Person = (function () {
    function Person(n, a) {
        this.name = n;
        this.age = a;
    }
    Person.prototype.greet = function (msg) {
        return "Hello";
    };
    Person.prototype.doWork = function () {
        return "I am working";
    };
    Person.prototype.doShopping = function () {
        console.log("Let's go to Mall");
    };
    return Person;
}());
//# sourceMappingURL=5_ClassAndInterface.js.map