import { IPoint, Point } from './PointModule.js';
// import { Component } from '@angular/core';
import * as $ from 'jquery';

let point: IPoint = new Point(2, 3);
console.log(point.getDistance());

// DOM Manipulation using HTML API's
document.getElementById("jsresult").innerHTML =
    point.getDistance().toString();

$(document).ready(function () {
    $("#jqresult").html(point.getDistance().toString());
});