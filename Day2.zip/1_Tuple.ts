// Tuple - Stores a fixed collection of values of same or varied types, 
// maintaining the sequence

// var arr: number[] = [10, 20, 30, 40, 50];

// var arr: (string | number)[] = ["Manish", 1];
// arr = ["Manish", "Sharma"];
// arr = [10, 20, 30];
// arr = [10, "ABC"];
// arr = [10, "ABC", 20, 39];

// let dataRow: [number, string] = [1, "Manish"];
// dataRow = ["Manish", "Sharma"];
// dataRow = [10, 20];
// dataRow = ["ABC", 10];
// dataRow = [1, "Manish", 411021];
